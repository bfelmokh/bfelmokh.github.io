
<html>
<head>
<title> Planner </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<script type="text/javascript">
        $(document).ready(function() {
            var arr = new Array();
            $("select[multiple]").change(function() {
                $(this).find("option:selected")
				if (this.name.substr(0,1)== "W" || this.name.substr(0,1)== "N"){
					limit=1;
				}
				else if (this.name.substr(0,1)== "A") {
					limit=4;
				}
				else{
					limit=2;
				}
                if ($(this).find("option:selected").length > limit) {
                    $(this).find("option").removeAttr("selected");
                    $(this).val(arr);
                }
                else {
                    arr = new Array();
                    $(this).find("option:selected").each(function(index, item) {
                        arr.push($(item).val());
                    });
                }
            });
        });
    </script>
<style>
.table td {
		text-align:center;
		vertical-align:middle;
	}
.table-striped>tbody>tr:nth-child(odd)>td, 
.table-striped>tbody>tr:nth-child(odd)>th {
   background-color:  #C50414;
   color:white}
   $theme-colors: (
  custom-color: #F00
);
</style>
</head>
<body>
<?php
if (!isset ($_GET['WEEK'])) {
	echo '<center><div class="alert-danger" > Sorry select week first add to url ?WEEK=$NumberOfWeek </div></center>';
	exit ;
}else{
	$_SESSION['WEEK']=$_GET['WEEK'];
}
?>
<?php
$supervisorlist=array("'Akram GRAMI'","'Amir KOUNI'","'Amal BENBLI'","'Amal ZITOUNI'","'Amal CHROUDI'","'Anis BENMEFTAH'","'BahaEddine SAHLI'","'Elmokhtar BENFRAJ'","'Imen BOUKHARI'","'Maroua TAGHOUTI'","'Maryam GHARBI'","'Mayssa CHAOUALI'","'Siwar GADDOUR'","'Wissem SMII'");


function getsupvervisor($supervisorlist,$S,$W) {
$dpm=array("'Elmokhtar BENFRAJ'","'Wissem SMII'","'Amal CHROUDI'","'Amir KOUNI'");
$courses1=array("'Amir KOUNI'","'Amal BENBLI'","'Maroua TAGHOUTI'","'Siwar GADDOUR'");
$courses2=array("'Amal CHROUDI'","'Amal ZITOUNI'","'Maryam GHARBI'","'Imen BOUKHARI'","'Anis BENMEFTAH'","'Akram GRAMI'");
$week_start = new DateTime();
$week_start->setISODate(date('Y'),$_SESSION['WEEK'],1);
$coursesweek=$week_start->format('d');
	?> <select name="<?php echo $S.$W; ?>" id="<?php echo $S.$W; ?>" class="custom-select" size=3 multiple >
<?php 

  for ($i=0;$i<14;$i++){
$class="";	  
	if ($S=="E" || $S=="A"){
		for ($sup=0;$sup<4;$sup++){
				if (strcmp($dpm[$sup],$supervisorlist[$i] )== 0)
					$class="badge-warning";
				
		}
	}
	if ( $S == "A" && ($coursesweek > 1 && $coursesweek < 13) && ((in_array($supervisorlist[$i], $courses1) && ($W==0 || $W==1)) || (in_array($supervisorlist[$i], $courses2) && ($W==3 || $W==4))) ) {
		echo "<option class='",$class,"' value=",$supervisorlist[$i]," selected >",$supervisorlist[$i]," - C </option>";
	}else{
		echo "<option class='",$class,"' value=",$supervisorlist[$i],">",$supervisorlist[$i],"</option>";
	}
  }
echo "</select>";
}
function showsupvervisor($supervisorlist,$S,$W) {
	?> <div name="<?php echo "R".$S.$W; ?>" id="<?php echo "R".$S.$W; ?>" class="div" >
<?php echo "</div>";
}
?>
<center><h1>Planner</h1><div id="msgdpm" class='alert-danger'></div></center>
<div class="table-responsive-lg">
	<table class="table">
		<tr>
		<th>Shifts</th>
			<?php
				$week_start = new DateTime();
				for($i=1;$i<8;$i++){
					$week_start->setISODate(date('Y'),$_SESSION['WEEK'],$i);
					echo "<th>",$week_start->format('D d M Y')," <br/><center><span id ='CA",(($i)-1),"' class='badge badge-pill badge-danger'>0</span></center></th>";
				}
			?>	
		</tr>
		<tr>
			<th>Absence <br/></th>
			<?php
				for($i=0;$i<7;$i++){
					echo "<td>";
					getsupvervisor($supervisorlist,'A',$i);
					echo "</td>";
				}
			?>
		</tr>
		<tr>
			<th>Early <br/><span class="badge badge-pill badge-warning">DPM</span></th>
			<?php
				for($i=0;$i<5;$i++){
					echo "<td>";
					getsupvervisor($supervisorlist,'E',$i);
					echo "</td>";
				}
			?>
			<?php
				for($i=5;$i<7;$i++){
					echo "<td rowspan='0'>";
					getsupvervisor($supervisorlist,'W',$i);
					echo "</td>";
				}
			?>			
		</tr>
		<tr>
			<th>Late</th>
			<?php
				for($i=0;$i<5;$i++){
					echo "<td>";
					getsupvervisor($supervisorlist,'L',$i);
					echo "</td>";
				}
			?>	
		</tr>
		<tr>
			<th>Night</th>
			<?php
				for($i=0;$i<5;$i++){
					echo "<td>";
					getsupvervisor($supervisorlist,'N',$i);
					echo "</td>";
				}
			?>	
		</tr>
		
		
</table>
</div>
<hr>
<div class="container">
<center>  <h1 class="final">FINAL</h1><span class="badge badge-pill badge-success">Hover FINAL to update Plan views</span><hr></center>
<div class="table-responsive-lg">
	<table class="table table-bordered table-striped">
			<tr>
		<th >Shifts</th>
			<?php
				$week_start = new DateTime();
				for($i=1;$i<8;$i++){
					$week_start->setISODate(date('Y'),$_SESSION['WEEK'],$i);
					echo "<th >",$week_start->format('D d M Y'),"</th>";
				}
			?>	
		</tr>
		<tr>
			<th>Early <br/><span class="badge badge-pill badge-warning">DPM</span></th>
			<?php
				for($i=0;$i<5;$i++){
					echo "<td>";
					showsupvervisor($supervisorlist,'E',$i);
					echo "</td>";
				}
			?>
			<?php
				for($i=5;$i<7;$i++){
					echo "<td rowspan='0'>";
					showsupvervisor($supervisorlist,'W',$i);
					echo "</td>";
				}
			?>			
		</tr>
		<tr>
			<th>Late</th>
			<?php
				for($i=0;$i<5;$i++){
					echo "<td>";
					showsupvervisor($supervisorlist,'L',$i);
					echo "</td>";
				}
			?>	
		</tr>
		<tr>
			<th>Night</th>
			<?php
				for($i=0;$i<5;$i++){
					echo "<td>";
					showsupvervisor($supervisorlist,'N',$i);
					echo "</td>";
				}
			?>	
		</tr>
	</table>
<div>
</div>


<script>
// UpdateFrom* functions : updating table view + Selector
supervisorlist=["'Akram GRAMI'","'Amir KOUNI'","'Amal BENBLI'","'Amal ZITOUNI'","'Amal CHROUDI'","'Anis BENMEFTAH'","'BahaEddine SAHLI'","'Elmokhtar BENFRAJ'","'Imen BOUKHARI'","'Maroua TAGHOUTI'","'Maryam GHARBI'","'Mayssa CHAOUALI'","'Siwar GADDOUR'","'Wissem SMII'"];
function updateFromWeekEnd(selectedSupervisor,day){
			resultID="#RW"+day
			$(resultID).text(selectedSupervisor);
}
function updateFromAbsence(selectedSupervisor,day){
			for (i=0; i<selectedSupervisor.length;i++){
			if (day < 5) {
				sup1="#E"+day+" option[value='"+selectedSupervisor[i]+"']";
				$(sup1).remove();
				sup1="#L"+day+" option[value='"+selectedSupervisor[i]+"']";
				$(sup1).remove();
				sup1="#N"+day+" option[value='"+selectedSupervisor[i]+"']";
				$(sup1).remove();
			}else{
				sup1="#W"+day+" option[value='"+selectedSupervisor[i]+"']";
				$(sup1).remove();
			}	
			}
			resultID="#CA"+day;
			$(resultID).text(selectedSupervisor.length);
}
function updateFromEarly(selectedSupervisor,day){
			sup1="#L"+day+" option[value='"+selectedSupervisor[0]+"']";
			sup2="#L"+day+" option[value='"+selectedSupervisor[1]+"']";
			$(sup1).remove();
			$(sup2).remove();
			sup1="#N"+day+" option[value='"+selectedSupervisor[0]+"']";
			sup2="#N"+day+" option[value='"+selectedSupervisor[1]+"']";
			$(sup1).remove();
			$(sup2).remove();
			resultID="#RE"+day
			$(resultID).text(selectedSupervisor);
}
function updateFromLate(selectedSupervisor,day){
			sup1="#E"+day+" option[value='"+selectedSupervisor[0]+"']";
			sup2="#E"+day+" option[value='"+selectedSupervisor[1]+"']";
			$(sup1).remove();
			$(sup2).remove();
			sup1="#N"+day+" option[value='"+selectedSupervisor[0]+"']";
			sup2="#N"+day+" option[value='"+selectedSupervisor[1]+"']";
			$(sup1).remove();
			$(sup2).remove();
			resultID="#RL"+day
			$(resultID).text(selectedSupervisor);
}
function updateFromNight(selectedSupervisor,day){
			sup1="#E"+day+" option[value='"+selectedSupervisor[0]+"']";
			sup2="#L"+day+" option[value='"+selectedSupervisor[0]+"']";
			$(sup1).remove();
			$(sup2).remove();
if ( day == 4 ) {			
			sup1="#W5 option[value='"+selectedSupervisor[0]+"']";
			$(sup1).remove();
			sup1="#W6 option[value='"+selectedSupervisor[0]+"']";
			$(sup1).remove();
}
			resultID="#RN"+day
			$(resultID).text(selectedSupervisor);
}
// valid* Functions for confirming that the selected Are OK.
function validEarly(){
	dpm=["Elmokhtar BENFRAJ","Wissem SMII","Amal CHROUDI","Amir KOUNI"];
	valid=true;
	vvdpm=true;
	for (i=0;i<5;i++){
		vdpm=false;
		sup = "#E"+i;
		limit = $(sup).find("option:selected").length;
		 if (limit != 2){
			valid=false;
		}else{
				// Check DPM
			for (d=0;d<4;d++){
				if(!(($(sup).children("option:selected").toArray().map(item => item.value)[0]!=dpm[d]) && ($(sup).children("option:selected").toArray().map(item => item.value)[1]!=dpm[d]))){
					vdpm=true;
					break;
				}
			}
			console.log(i,d,vdpm);
		if (!vdpm) {
			vvdpm=false;
		}
		}
		
		console.log("VVDPM: ",vvdpm);
	}
	for (j=0;j<5;j++){
			sup1="#L"+j;
			sup2="#N"+j;
			if ((valid == true) && (vvdpm == true)){
				$(sup1).attr("disabled",false);
				$('#msgdpm').text('');
			}else if ((valid == true) && (vvdpm == false)){
				$(sup1).attr("disabled",true);
				$(sup2).attr("disabled",true);
				$("#msgdpm").text("Please Check Again, DPM Animator is required !");
			}
			else{
				$(sup1).attr("disabled",true);
				$(sup2).attr("disabled",true);
				$("#msgdpm").text("2 Supervisor must be selected in early per day");
			}
		} 
}
function validLate(){
	valid=true;
	for (i=0;i<5;i++){
		sup = "#L"+i;
		limit = $(sup).find("option:selected").length;
		 if (limit != 2){
			valid=false;
		}
	}
	for (j=0;j<5;j++){
			sup2="#N"+j;
			if (valid == true){
				$(sup2).attr("disabled",false);
				$("#msgdpm").text("");
			}else{
				$(sup2).attr("disabled",true);
				$("#msgdpm").text("2 Supervisor must be selected in Late per day");
			}
		} 
}
$('body').ready(function(){
		validEarly();
});
</script>
<script >
	$('select').on('mouseleave', function() {
		var shift = this.name.substr(0,1);
		var day = this.name.substr(1,1);
		if ( shift == 'A' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			updateFromAbsence(selectedSupervisor,day);
			//validAbsence();
		}
		if ( shift == 'E' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			updateFromEarly(selectedSupervisor,day);
			validEarly();
		}
		else if ( shift == 'L' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			updateFromLate(selectedSupervisor,day);
			validLate();
		}
		else if ( shift == 'N' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			updateFromNight(selectedSupervisor,day)
		}else if ( shift == 'W' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			updateFromWeekEnd(selectedSupervisor,day)
		}
	});
	$('select').on('mouseover', function() {
		var shift = this.name.substr(0,1);
		var day = this.name.substr(1,1);
		if ( shift == 'E' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			//updateEarly(selectedSupervisor,day);
		}
		else if ( shift == 'L' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			//updateLate(selectedSupervisor,day);
		}
		else if ( shift == 'N' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			//updateNight(selectedSupervisor,day)
		}else if ( shift == 'W' ) {
			var selectedSupervisor = $(this).children("option:selected").toArray().map(item => item.value);
			//updateWeekEnd(selectedSupervisor,day)
		}
	});
	
	$('.final').on('mouseover', function() {
			tab=[];
			etab=[];
			ltab=[];
			ntab=[];
			wtab=[];
			shiftsnames=["E","L","N"];
			colsp=[];
			for (s=0;s<3;s++ ){
			colsplength=1;
			lastcolsp=0;
			indicecolsp=0;
				for (i=0;i<5;i++){
					RWID="#R"+shiftsnames[s]+i;
					tab[i] = $(RWID).text();
					if ( shiftsnames[s] == 'E' ) {
						etab[i]=tab[i];
					}else if ( shiftsnames[s] == 'L' ) {
						ltab[i]=tab[i];
					}else if ( shiftsnames[s] == 'N' ) {
						ntab[i]=tab[i];
					}
					if (i>0){
						if (tab[lastcolsp]==tab[i]){
							colsplength++;
							$(RWID).parent().hide();
							RWIDTMP="#R"+shiftsnames[s]+lastcolsp;
							$(RWIDTMP).parent().attr("colspan",colsplength);
						}else{
							$(RWID).parent().show();
							indicecolsp++;
							lastcolsp=i;
							colsplength=1;
						}
					}else{
							RWIDTMP="#R"+shiftsnames[s]+lastcolsp;
							$(RWIDTMP).parent().attr("colspan",colsplength);
					}
					
				}
			}
		RWID="#RW6";
		RWIDTMP="#RW5";
		wtab[5]=$(RWID).text();
		wtab[6]=$(RWIDTMP).text();
		if ( $(RWID).text() == $(RWIDTMP).text() ){
			$(RWID).parent().hide();
			$(RWIDTMP).parent().attr("colspan",2);
		} else{
			$(RWID).parent().show();
			$(RWIDTMP).parent().attr("colspan",1);
		}
		
		
	});
	$('.final').on('click', function() {
		console.log(etab,ltab,ntab,wtab);
	});
</script>
</body>
</html>